﻿///////////////

//nazwa funkcji: GeneratePassword
//opis funkcji: Generuje 12-znakowe hasło, zawierające 3 losowe małe litery, 3 wielkie litery, 2 polskie znaki, 2 cyfry, 2 znaki specjalne 
//parametry: < nazwa i opis parametru1, lub „brak”>
//<nazwa i opis parametru2>
//zwracany typ i opis: < nazwa typu i opis co jest zwracane lub „brak”> 
//autor: < numer zdającego >

///////////////
string GeneratePassword()
{
    string lowerCase = "abcdefghijklmnoprstuwxyz";
    string upperCase = "ABCDEFGHIJKLMNOPRSTUWXYZ";
    string specialLetters = "ąęćśłóńźżĄĘŁŃÓŚĆŻŹ";
    string numbers = "0123456789";
    string specialSymbols = "!@#$%^&*()_+";
    string password = "";

    Random random = new Random();
    for(int i = 0; i < 3; i++)
    {
        int indexLowerCase = random.Next(lowerCase.Length - 1);
        password += lowerCase.Substring(indexLowerCase, 1);

        int indexUpperCase = random.Next(lowerCase.Length - 1);
        password += upperCase.Substring(indexUpperCase, 1);

        if(i < 2)
        {
            int indexSpecialLetters = random.Next(specialLetters.Length - 1);
            password += specialLetters.Substring(indexSpecialLetters, 1);

            int indexNumbers = random.Next(numbers.Length - 1);
            password += numbers.Substring(indexNumbers, 1);

            int indexSpecialSymbols = random.Next(specialSymbols.Length - 1);
            password += specialSymbols.Substring(indexSpecialSymbols, 1);
        }
    }

    return password;
}
Console.WriteLine("Losowe hasła: ");
for(int i = 0; i < 5; i++)
{
    Console.WriteLine(GeneratePassword());
}